#include <stdio.h>
#include <stdlib.h>
#include "biblioteca.h"

int main(void)
{
    struct no* Cabeca=NULL;
    
    inserir_nrec(&Cabeca, 1);
    inserir_nrec(&Cabeca, 2);
    imprime_gamute(Cabeca);
    
    /*inserir_rec(&Cabeca, 5);
    imprime_gamute(Cabeca);

    inserir_rec(&Cabeca, 1);
    imprime_gamute(Cabeca);
    
    inserir_rec(&Cabeca, 5);
    imprime_gamute(Cabeca);

    inserir_rec(&Cabeca, 2);
    imprime_gamute(Cabeca);
 
    inserir_rec(&Cabeca, 7);
    imprime_gamute(Cabeca);

    inserir_rec(&Cabeca, 3);
    imprime_gamute(Cabeca);

    inserir_rec(&Cabeca, 9);
    imprime_gamute(Cabeca);

    inserir_rec(&Cabeca, 1);
    imprime_gamute(Cabeca);

    inserir_rec(&Cabeca, 5);
    imprime_gamute(Cabeca);

    inserir_rec(&Cabeca, 2);
    imprime_gamute(Cabeca);

    delete_lista_rec(&Cabeca);
    imprime_gamute(Cabeca);*/
}
