#include <stdio.h>
#include <stdlib.h>

#include "biblioteca.h"

void inserir_rec(struct no** apont, long int valor)
{
    if ( (*apont) && ((*apont)->pixel < valor) )
    {
        inserir_rec(&(*apont)->proximo, valor);
    }
    else
    {
        if((!*apont) || ((*apont)->pixel > valor))
        { 
            struct no* aux = (struct no*) malloc(sizeof(struct no));
            aux->pixel = valor;
            aux->proximo = *apont;
            *apont = aux;
        }
    }
}

void inserir_nrec(struct no** apont, long int valor)
{
    //insera o seu codigo aqui
    struct no* novo = (struct no*) malloc(sizeof(struct no));
    novo->pixel = valor;
    if((*apont)==NULL)
    {
        novo->proximo = *apont;
        *apont = novo;
    }
    else
    {
        struct no* pointer = *apont;
        struct no* ant = NULL;
        while(pointer!=NULL && pointer->pixel < valor)
        {
            ant = pointer;
            pointer = pointer->proximo;
        }
        novo->proximo = pointer;
        ant->proximo = novo;
    }
}

void imprime_gamute(struct no* apont)
{
    // insira o seu codigo aqui
    if(apont != NULL)
    {
        struct no* pointer = apont;
        while(pointer != NULL)
        {
            printf("%ld ", pointer->pixel);
            pointer = pointer->proximo;
        }
    }
}


void delete_lista_rec(struct no** apont)
{
    // insira o seu codigo aqui
    if((*apont) != NULL)
    {
        while((*apont) != NULL)
        {
            struct no* pointer = *apont;
            (*apont) = (*apont)->proximo;
            free(pointer);
        }
    }
    *apont = NULL;
}

int gamute_insere_rec(struct no** apont, FILE* apontArq, char *nome)
{
    // insira o seu codigo aqui
    int n;
    char name[3];
    fscanf(apontArq, "%d", &n);
    fscanf(apontArq, "%s", name);
    fscanf(apontArq, "%d", &n);
    fscanf(apontArq, "%d", &n);
    while((fscanf(apontArq, "%d", &n))!=EOF)
    {
        inserir_rec(apont, n);   
    }
    fclose(apontArq);
}

int gamute_insere_nrec(struct no** apont, FILE* apontArq, char *nome)
{
    // insira o seu codigo aqui
    int n;
    char name[3];
    fscanf(apontArq, "%d", &n);
    fscanf(apontArq, "%s", name);
    fscanf(apontArq, "%d", &n);
    fscanf(apontArq, "%d", &n);
    while(fscanf(apontArq, "%d", &n)!=EOF)
    {
        inserir_nrec(apont, n);   
    }
    fclose(apontArq);
}

