#include <stdio.h>
#include <stdlib.h>
#include "biblioteca.h"

int main(int argc, char* argv[])
{
    int codigo;
    FILE* arquivo = NULL;
    if (argc!=2)
    {
        fprintf(stderr, "Número de parâmetros inválido. O programa admite somente 2 parâmetros de linha de comando\n.");
        exit(-1);
    }
    if ((arquivo=fopen(argv[1], "r"))==NULL)
    {
        fprintf(stderr, "Não foi possível abrir o arquivo %s.\n",argv[1]);
        exit(-2);
    }

    struct no* cabeca=NULL;
    if (codigo = gamute_insere_rec(&cabeca, arquivo, argv[1]))
        printf("A função gamute retornou com erro %d\n", codigo);
    fclose(arquivo);
    imprime_gamute(cabeca);
    delete_lista_rec(&cabeca);
    imprime_gamute(cabeca);
}
