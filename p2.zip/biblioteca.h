#include <stdio.h>

#ifndef BIBLIOTECA_H_INCLUDED
#define BIBLIOTECA_H_INCLUDED

struct no{
    long int pixel;
    struct no* proximo;
};

void inserir_rec(struct no**, long int);

void inserir_nrec(struct no**, long int);

void imprime_gamute(struct no*);

int gamute_insere_rec(struct no**, FILE*, char*);

int gamute_insere_nrec(struct no**, FILE*, char*);

void delete_lista_rec(struct no**);

#endif //BIBLIOTECA_H_INCLUDED
